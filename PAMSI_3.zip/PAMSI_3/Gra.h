#pragma once
#include <iostream>
#define GRACZ_X 'X'
#define GRACZ_O 'O'
using namespace std;


/*! \file Klasa GraKiK
 *
 * Zawiera klase GraKIK i jej metody
 * wraz z algorytmem minmax
 *
 */




/*! \brief Definicja klasy GraKiK
 *
 */

class GraKiK
{

    char **P;
    int rozmiar;
    int IleAbyWygrac;
    public:
    GraKiK();


    GraKiK(int bok);

//   cout<<"Sukces"<<endl;


/*! \brief Wypisz Plansze
 *  typ void, nic nie przyjmuje
 *  Wypisuje plansze na stdio
 */
    void WypiszPlansze();



/*! \brief CZy Wygrana
 *  typ bool, nic nie przyjmuje
 *  Sprawdza zcy aktualny uklad planszy
 * jest zwycieski dla ktoregos z graczy
 */
    bool CzyWygrana(char Gracz);


/*! \brief Przygotu Plansze
 *  typ void, nic nie przyjmuje
 *  Przywraca pierwotne ustawienie planszy
 * wypelnia ja znakami ' ' - tworzy pusta plansze
 */
    void PrzygotujPlanszeDoGry();



/*! \brief Czy wolne pole
 *  typ bool, nic nie przyjmuje
 *  sprawdza czy jest wolne pole w tablicy
 */
    bool CzyJestWolnePole();


/*! \brief Przygotu Plansze
 *  typ void, przyjmuje char
 * realizuje rucha gracza, podanego jako argument
 */
    void TuraGracza(char Gracz);


/*! \brief Przygotu Plansze
 *  typ int, przyjmuje int i char
 *  realizuje algorytm minmax i wykonuje ruch komputera
 */
    int MiniMax(int poziom, char gracz, int Glebokosc);

};
