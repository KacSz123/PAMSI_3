#include <iostream>
using namespace std;
#include "testy.h"



int main()
{

   FinalnaGra();

    return 0;
}
