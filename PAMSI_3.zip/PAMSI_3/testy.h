#pragma once
#include "Gra.h"
#include <iostream>
/*! \file
 *
 *  Funckjde realizujace testy i oraz gry
 *
 */



/*! \brief Gra z komputerem jako krzyzyk
 *
 *  realizuje kre w kolko i krzyzyk z komputerem
 *  czlowiek jest 'X'
 */
void GraPvC_Krzyzyk();



/*! \brief Gra z komputerem jako jako kolko
 *
 *  realizuje kre w kolko i krzyzyk z komputerem
 *  czlowiek jest 'O'
 */
void GraPvC_Kolko();



/*! \brief Gra czlowieka z czlowiekiem w kolko i krzyzyk
 *
 *  realizuje kre w kolko i krzyzyk
 */
void GraPvP();



/*! \brief menu
 *
 * wyswietla menu nawigacyjne
 */
void pokazMenu();




/*! \brief Zapis przeprowadzanych testów
 *
 *
 */
void Testy();



/*! \brief FinalnaGra
 *
 *  glownA funckja realizujaca gre, umozliwia wybor trybu
 */
void FinalnaGra();
